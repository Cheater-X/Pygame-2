import pygame
import sys
import os

pygame.init()

size = width, height = 1000, 600
screen = pygame.display.set_mode(size)
clock = pygame.time.Clock()
running = True






class Sprite(pygame.sprite.Sprite):

    def __init__(self, group):
        super().__init__(group)
        self.rect = None

    def get_event(self, event):
        pass

class SpriteGroup(pygame.sprite.Group):

    def __init__(self):
        super().__init__()

    def shift(self, vector):
        global level_map
        if vector == "left":
            max_lay_x = max(self, key=lambda sprite:
            sprite.abs_pos[0]).abs_pos[0]
            for sprite in self:
                if sprite.abs_pos[0] == max_lay_x:
                    sprite.abs_pos[0] -= tile_width * max_x



def load_level(filename):
    filename = filename
    with open(filename, 'r') as mapFile:
        level_map = [line.strip() for line in mapFile]
    max_width = max(map(len, level_map))
    return list(map(lambda x: x.ljust(max_width, '-'), level_map))


tile_images = {'block': pygame.image.load('stena.png')}
tile_images1 = {"fon": pygame.image.load("fon.jpg")}
play_image = pygame.image.load('set1.jpg')
colorkey = play_image.get_at((10, 10))
play_image.set_colorkey(colorkey)
play_image = play_image.convert_alpha()
tile_width = tile_height = 120
player = None
all_sprites = pygame.sprite.Group()
tiles_group = pygame.sprite.Group()
player_group = pygame.sprite.Group()
level_map = load_level("karta.txt")
sprite_group = SpriteGroup()
hero_group = SpriteGroup()

class Tile(Sprite):
    def __init__(self, tile_type, pos_x, pos_y):
        super().__init__(sprite_group)
        self.image = tile_images['block']
        self.rect = self.image.get_rect().move(
            tile_width * pos_x, tile_height * pos_y)
        self.abs_pos = [self.rect.x, self.rect.y]


    def set_pos(self, x, y):
        self.abs_pos = [x, y]

class Tile1(Sprite):
    def __init__(self, tile_type, pos_x, pos_y):
        super().__init__(sprite_group)
        self.image = tile_images1['fon']
        self.rect = self.image.get_rect().move(
            tile_width * pos_x, tile_height * pos_y)
        self.abs_pos = [self.rect.x, self.rect.y]


    def set_pos(self, x, y):
        self.abs_pos = [x, y]


class Player(Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(hero_group)
        self.image = play_image
        self.rect = self.image.get_rect().move(
            tile_width * pos_x + 15, tile_height * pos_y + 5)
        self.pos = (pos_x, pos_y)
    def move(self, x, y):
        print(x, y)
        camera.dx = -((tile_width) * (x - self.pos[0]))
        camera.dy = (tile_height) * (y - self.pos[1])
        print(camera.dx, camera.dy)
        self.pos = (x, y)
        for sprite in sprite_group:
            camera.apply(sprite)

class Camera:
    def __init__(self):
        self.dx = 0
        self.dy = 0

    def apply(self, obj):
        obj.rect.x += self.dx
        obj.rect.y += self.dy

    def update(self, target):
        self.dx = 0
        self.dy = 0
def generate_level(level):
    new_player, x, y = None, None, None
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '+':
                Tile('block', x, y)
            elif level[y][x] == '-':
                Tile1("fon", x, y)
            elif level[y][x] == '@':
                'Tile(play_image, x, y)'
                new_player = Player(x, y)
                # вернем игрока, а также размер поля в клетках
    return new_player, x, y

player, level_x, level_y = generate_level(load_level('karta.txt'))



def move(hero, movement):
    x, y = hero.pos
    if movement == "right":
        prev_x = x + 1 if x != 0 else max_x
        if level_map[y][prev_x] == "-" or level_map[y][prev_x] == "@":
            if prev_x == max_x:
                for i in range(max_x - 1):
                    sprite_group.shift("right")
                hero.move(prev_x - 1, y)
            else:
                sprite_group.shift("left")
                hero.move(prev_x, y)
    elif movement == "left":
        next_x = x - 1 if x != max_x else 0
        if level_map[y][next_x] == "-" or level_map[y][next_x] == "@":
            if next_x == 0:
                for i in range(max_x - 1):
                    sprite_group.shift("left")
                hero.move(next_x + 1, y)
            else:
                sprite_group.shift("right")
                hero.move(next_x, y)






camera = Camera()

level_map = load_level("karta.txt")
hero, max_x, max_y = generate_level(level_map)
camera.update(hero)



while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                move(hero, "left")
            elif event.key == pygame.K_RIGHT:

                move(hero, "right")
    screen.fill(pygame.Color("black"))
    sprite_group.draw(screen)
    hero_group.draw(screen)
    pygame.display.flip()
    clock.tick(50)
pygame.quit()



